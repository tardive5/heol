This dir contains unit tests for use with the testthat package. 
They are intended to be tested by a non-root user.
To run them, install this package and run:

library(testthat)
test_package("jsonlite")
